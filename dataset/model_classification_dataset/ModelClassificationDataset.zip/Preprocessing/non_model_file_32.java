package de.ktran.anno1404warenrechner.helpers;

public interface CompatConsumer<T> {
    void accept(T item);
}