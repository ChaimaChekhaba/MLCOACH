package com.aliasadi.mvvm.ui.base;

import android.arch.lifecycle.ViewModel;

/**
 *  Created by Ali Asadi on 07/01/2019.
 */
public abstract class BaseViewModel extends ViewModel {
}