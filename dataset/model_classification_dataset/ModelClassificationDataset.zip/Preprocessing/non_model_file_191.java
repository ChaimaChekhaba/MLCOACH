package com.nawin.androidmvparchitecture;

/**
 * Created by nawin on 1/6/17.
 */

public interface BasePresenter {
    void start();
    void stop();
}