package de.ktran.anno1404warenrechner.views;

public interface HasLifecycle {
    void onStart();
    void onStop();
}